import React, { useState } from "react";
import type { Group, Member, Expense } from "./types.ts";
import GroupList from "./components/GroupList";
import CreateGroup from "./components/CreateGroup";
import GroupView from "./components/GroupView";

const App: React.FC = () => {
  const [groups, setGroups] = useState<Group[]>([]);
  const [selectedGroup, setSelectedGroup] = useState<Group | null>(null);

  return (
    <div className="container">
      <h1>Google Pay Split-Bill Redesign</h1>
      {!selectedGroup ? (
        <>
          <CreateGroup groups={groups} setGroups={setGroups} />
          <GroupList groups={groups} selectGroup={setSelectedGroup} />
        </>
      ) : (
        <GroupView
          group={selectedGroup}
          goBack={() => setSelectedGroup(null)}
          setGroups={setGroups}
          groups={groups}
        />
      )}
    </div>
  );
};

export default App;



