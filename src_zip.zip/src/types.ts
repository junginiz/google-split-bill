export interface Member {
  id: number;
  name: string;
}

export interface Expense {
  id: number;
  title: string;
  amount: number;
  payerId: number;
  splits: { memberId: number; share: number }[];
}

export interface Group {
  id: number;
  name: string;
  members: Member[];
  expenses: Expense[];
}
