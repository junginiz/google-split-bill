import React, { useState } from "react";
import type { Group, Expense } from "../types";

interface Props {
  group: Group;
  addExpense: (expense: Expense) => void;
}

const AddExpense: React.FC<Props> = ({ group, addExpense }) => {
  const [title, setTitle] = useState("");
  const [amount, setAmount] = useState<number>(0);
  const [payerId, setPayerId] = useState<number>(group.members[0]?.id || 0);

  const submitExpense = () => {
    if (!title || !amount || !payerId) return;
    const splitAmount = amount / group.members.length;
    const expense: Expense = {
      id: Date.now(),
      title,
      amount,
      payerId,
      splits: group.members.map((m) => ({ memberId: m.id, share: splitAmount })),
    };
    addExpense(expense);
    setTitle("");
    setAmount(0);
  };

  return (
    <div style={{ marginTop: "15px" }}>
      <input
        placeholder="Expense Title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
      />
      <input
        type="number"
        placeholder="Amount"
        value={amount}
        onChange={(e) => setAmount(Number(e.target.value))}
      />
      <select value={payerId} onChange={(e) => setPayerId(Number(e.target.value))}>
        {group.members.map((m) => (
          <option key={m.id} value={m.id}>
            {m.name}
          </option>
        ))}
      </select>
      <button onClick={submitExpense}>Add Expense</button>
    </div>
  );
};

export default AddExpense;
