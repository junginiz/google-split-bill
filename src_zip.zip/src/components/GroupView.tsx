import React, { useState } from "react";
import type { Group, Expense } from "../types";
import AddExpense from "./AddExpenses";

interface Props {
  group: Group;
  goBack: () => void;
  groups: Group[];
  setGroups: React.Dispatch<React.SetStateAction<Group[]>>;
}

const GroupView: React.FC<Props> = ({ group, goBack, groups, setGroups }) => {
  const [showAddExpense, setShowAddExpense] = useState(false);

  const addExpense = (expense: Expense) => {
    const updatedGroup = { ...group, expenses: [...group.expenses, expense] };
    const updatedGroups = groups.map((g) =>
      g.id === group.id ? updatedGroup : g
    );
    setGroups(updatedGroups);
  };

  const balances = group.members.map((m) => {
    const paid = group.expenses
      .filter((e) => e.payerId === m.id)
      .reduce((sum, e) => sum + e.amount, 0);
    const owed = group.expenses
      .flatMap((e) => e.splits)
      .filter((s) => s.memberId === m.id)
      .reduce((sum, s) => sum + s.share, 0);
    return { member: m.name, net: paid - owed };
  });

  return (
    <section>
      <button onClick={goBack}>Back</button>
      <h2>{group.name}</h2>
      <button onClick={() => setShowAddExpense(!showAddExpense)}>
        {showAddExpense ? "Cancel" : "Add Expense"}
      </button>
      {showAddExpense && <AddExpense group={group} addExpense={addExpense} />}
      <h3>Balances</h3>
      {balances.map((b) => (
        <div key={b.member} className="balance">
          <span>{b.member}</span>
          <span>{b.net >= 0 ? `Owed ${b.net}` : `Owes ${-b.net}`}</span>
        </div>
      ))}
      <h3>Expenses</h3>
      {group.expenses.map((e) => (
        <div key={e.id} className="expense">
          <span>{e.title} - {e.amount}</span>
          <span>
            Paid by {group.members.find((m) => m.id === e.payerId)?.name}
          </span>
        </div>
      ))}
    </section>
  );
};

export default GroupView;
