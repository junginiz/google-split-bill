import React from "react";
import type { Group } from "../types";

interface Props {
  groups: Group[];
  selectGroup: (group: Group) => void;
}

const GroupList: React.FC<Props> = ({ groups, selectGroup }) => {
  return (
    <section>
      <h2>Groups</h2>
      {groups.length === 0 ? (
        <p>No groups yet</p>
      ) : (
        groups.map((g) => (
          <div key={g.id} className="group">
            <span>{g.name}</span>
            <button onClick={() => selectGroup(g)}>View</button>
          </div>
        ))
      )}
    </section>
  );
};

export default GroupList;
