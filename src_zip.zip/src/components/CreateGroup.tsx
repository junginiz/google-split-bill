import React, { useState } from "react";
import type { Group, Member } from "../types";

interface Props {
  groups: Group[];
  setGroups: React.Dispatch<React.SetStateAction<Group[]>>;
}

const CreateGroup: React.FC<Props> = ({ groups, setGroups }) => {
  const [name, setName] = useState("");
  const [membersInput, setMembersInput] = useState("");

  const addGroup = () => {
    if (!name || !membersInput) return;
    const members: Member[] = membersInput.split(",").map((n, i) => ({
      id: i + 1,
      name: n.trim(),
    }));
    const newGroup: Group = {
      id: groups.length + 1,
      name,
      members,
      expenses: [],
    };
    setGroups([...groups, newGroup]);
    setName("");
    setMembersInput("");
  };

  return (
    <section>
      <h2>Create Group</h2>
      <input
        placeholder="Group Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <input
        placeholder="Members (comma separated)"
        value={membersInput}
        onChange={(e) => setMembersInput(e.target.value)}
      />
      <button onClick={addGroup}>Add Group</button>
    </section>
  );
};

export default CreateGroup;

